Collide is a simple game where the player has to dodge an increasing number of enemy's. 
It needs python and pygame to run, so you'll have to install these to play. (http://www.pygame.org/install.html)
If you have any troubles, contact me, johnowhitaker@yahoo.com and i'll do my best to fix them.

If you're running ubuntu or a similar linux distro, you can copy collide.desktop 
to /usr/share/applications after modifying the paths to the program and icon, and then 
you'll be able to run it from you applications menu.
